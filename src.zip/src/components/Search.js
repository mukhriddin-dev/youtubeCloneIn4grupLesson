import React from 'react';
import { BsSearch, BsMicFill,BsBell } from 'react-icons/bs';
import { RiVideoAddLine } from 'react-icons/ri';
import {MdApps} from 'react-icons/md';
import user from '../images/user.jpg';

function Search(props) {
  return (
    <>
      <div className="search-container">
        <input
         type="text"
         className="search-input"
         placeholder='запрос для поиска'
         />
        <button className='button'><BsSearch /></button>
        <BsMicFill  className='micro'/>
      </div>

     
        <div className="users_set">
          <RiVideoAddLine />
          <MdApps/>
          <BsBell/>
          <img src={user} alt="avatar" className='avatar'/>
        </div>
      
    </>
  );
}

export default Search;