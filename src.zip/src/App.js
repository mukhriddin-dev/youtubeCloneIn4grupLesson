import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import './Style.css';
import {useState} from 'react';

import {FcMenu} from 'react-icons/fc';  

function App() {
  const [showToogle,setShowToogle] =useState(false);
  const handleShow =()=>{setShowToogle((m)=>!m)}
  console.log(showToogle)

  return (
    <>
    <Navbar>
      <FcMenu onClick={handleShow} className='toogle-sidebar'/>
    </Navbar>
    <Sidebar showToogle={showToogle}/>
    </>
  );
}

export default App;